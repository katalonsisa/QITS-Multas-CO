<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_secretaria</name>
   <tag></tag>
   <elementGuidId>81ca3fc2-d5e5-485d-b562-a4c9c1930992</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='content:selectSecretaria']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>content:selectSecretaria</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>content:selectSecretaria</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>size</name>
      <type>Main</type>
      <value>1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>PrimeFaces.ab({source:this,event:'change',process:'content:selectSecretaria'}, arguments[1]);</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>	
	Abejorral
	Abrego
	Acacias
	Aguachica
	Aguadas
	Aguazul
	Agustin Codazzi
	Aipe
	Albania
	Alvarado
	Amaga
	Amalfi
	Andalucia
	Andes
	Angostura
	Anserma
	Ansermanuevo
	Ant-Dag
	Ant-Sua
	Ant-VillaR
	Anza
	Apartado
	Apía
	Aracataca
	Aranzazu
	Aratoca
	Arauca
	Arboletes
	Arjona
	Armenia
	Armero - Guayabal
	Atlantico
	Baranoa
	Baraya
	Barbosa
	Barbosa (Sant)
	Barranca de Upia
	Barrancabermeja
	Barranquilla
	Belen de los Andaquies
	Bello
	Belén de Umbría
	Betania
	Betulia
	Bogotá D.C.
	Bolivar
	Bolivar
	Bolivar (Dept)
	Bosconia
	Briceño_Ant
	Bucaramanga
	Buenaventura
	Buenavista
	Buesaco
	Buga
	Bugalagrande
	Caceres
	Caicedonia
	Cajamarca
	Cajibio
	Calarca
	Caldas (Ant)
	Caldono
	Caloto
	Campo de la Cruz
	Campoalegre
	Candelaria
	Caqueza
	Carepa
	Carmen de Bolivar
	Carmen de Viboral
	Carolina del Principe
	Cartagena
	Cartago
	Caucasia
	Cañasgordas
	Cerete
	Chaparral
	Charala
	Chia
	Chigorodó
	Chinchina
	Chinu
	Chiquinquira
	Chiriguaná
	Choconta
	Cienaga
	Cimitarra
	Circasia
	Cisneros
	Ciudad Bolivar
	Clemencia
	Cocorna
	Combita
	Concordia
	Convencion
	Copacabana
	Cordoba
	Cordoba (Dept)
	Corinto
	Corozal
	Cota
	Cucuta
	Cumaral
	Curiti
	Curumaní
	DATT
	Dagua
	Darien
	Departamental Chocó
	Desc
	Desconocida
	Desconocida
	Don Matias
	Dosquebradas
	Duitama
	Ebejico
	El Carmen de Atrato
	El Cerrito
	El Paujil
	El Peñol
	El Playon
	El Retiro
	El Rosal
	El Tambo
	El banco
	Entrerrios
	Envigado
	Espinal
	Facatativa
	Federación Colombiana de Mpios
	Filandia
	Flandes
	Florencia
	Florencia
	Florida
	Floridablanca
	Fonseca
	Fredonia
	Fresno
	Frontino
	Fundación
	Funza
	Fusagasuga
	Galapa
	Garagoa
	Garzon
	Genova
	Ginebra
	Ginebra (Valle)
	Giraldo
	Girardot
	Girardota
	Giron
	Gomez Plata
	Granada (Meta)
	Guacari
	Guachucal
	Guadalupe
	Guajira
	Guamal (Meta)
	Guamo
	Guamo (Bolivar)
	Guarne
	Guarne(Dptal)
	Guatape
	Guateque
	Guatica
	Guayabetal
	Heliconia
	Herveo
	Hispania
	Honda
	Huila (Dept)
	ITBOY
	Ibague
	Imues
	Ipiales
	Istmina
	Itaguí
	Jamundi
	Jardin
	Jericó
	Juzgado
	La Calera
	La Ceja
	La Cumbre
	La Dorada
	La Estrella
	La Hormiga
	La Pintada
	La Plata
	La Tebaida
	La Union (Valle)
	La Unión (Ant)
	La Unión (Nariño)
	La Virginia
	Lebrija
	Lerida
	Leticia
	Libano
	Lorica
	Los Patios
	Luruaco
	Maceo
	Magangue
	Maicao
	Malaga
	Malambo
	Manizales
	Manzanares
	Marinilla
	Mariquita Departamental
	Mariquita Municipal
	Marmato
	Medellin
	Melgar
	Mercaderes
	Meta (Dept)
	Miraflores
	Miranda
	Mocoa
	Mompos
	Moniquira
	Montenegro
	Monteria
	Mosquera
	Nariño (Dept.)
	Necocli
	Neira
	Neiva
	Nobsa
	Obando
	Ocaña
	Oiba
	Orito
	POLCA
	Pacho
	Paipa
	Palermo
	Palestina
	Palmar de Varela
	Palmira
	Pamplona
	Pasto
	Patia (El Bordo)
	Pensilvania
	Pereira
	Piedecuesta
	Piendamo
	Pijao
	Pinchote
	Pitalito
	Planadas
	Planeta Rica
	Plato
	Policía Nacional
	Ponedera
	Popayan
	Pradera
	Puente Nacional
	Puerto Asis
	Puerto Berrio
	Puerto Boyacá
	Puerto Carreño
	Puerto Colombia
	Puerto Inírida
	Puerto López
	Puerto Salgar
	Puerto Tejada
	Puerto Triunfo
	Pupiales
	Purificacion
	Quibdo
	Quimbaya
	Quinchia
	Ramiriqui
	Remedios
	Restrepo
	Restrepo
	Ricaurte
	Rioblanco
	Riofrio
	Riohacha
	Rionegro
	Rionegro (Sant)
	Riosucio
	Risaralda
	Robles (La Paz)
	Roldanillo
	Rosas
	Rovira
	SAN CARLOS
	Sabana de Torres
	Sabanagrande
	Sabanalarga
	Sabaneta
	Saboya
	Sahagun
	Salamina
	Salento
	Salgar
	Samaniego
	Sampues
	San Alberto
	San Andrés
	San Francisco
	San Gil
	San Jeronimo
	San Jose del Guaviare
	San Juan de Nepomuceno
	San Luis
	San Pedro
	San Pedro de los Milagros
	San Rafael
	San Roque
	San Vicente
	San Vicente de Chucurí
	San Vicente del Caguan
	Sandona
	Santa Barbara
	Santa Fe de Antioquia
	Santa Marta
	Santa Rosa de Cabal
	Santa Rosa de Osos
	Santa Rosa de Viterbo
	Santander (Cauca)
	Santander de Quilichao
	Santo Domingo
	Santo Tomás
	Santuario
	Saravena
	Sede Central REMO
	Sede Central SERVIT
	Sede Central SEVIAL
	Sede Central SIMIT CAPITAL
	Sede Central SIMIT OCCIDENTE
	Segovia
	Sevilla
	Sibundoy
	Simit
	Since
	Sincelejo
	Soacha
	Soata
	Socorro
	Sogamoso
	Soledad
	Sonson
	Sopetran
	Suaita
	Suan
	Suarez
	Supia
	Tame
	Taraza
	Tarqui
	Tarso
	Tibasosa
	Timana
	Timbio
	Titiribi
	Toro
	Totoro
	Tubara
	Tulua
	Tumaco
	Tunja
	Tuquerres
	Turbaco
	Turbo
	Ubate
	Uramita
	Urrao
	Usiacurí
	Valdivia
	Valledupar
	Valparaiso
	Velez
	Venecia
	Vijes
	Villa Rica
	Villa de Leyva
	Villa del Rosario
	Villamaria
	Villarrica
	Villavicencio
	Villeta
	Viterbo
	Viterbo
	Yarumal
	Yolombo
	Yopal
	Yotoco
	Yumbo
	Zarzal
	Zipaquira
	Zulia (Dept)
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content:selectSecretaria&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//select[@id='content:selectSecretaria']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='content']/table/tbody/tr/td[2]/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Aceptar'])[4]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//select</value>
   </webElementXpaths>
</WebElementEntity>
